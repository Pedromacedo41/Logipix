public enum Position{
	UP, DOWN, LEFT, RIGHT, EMPTY
}

