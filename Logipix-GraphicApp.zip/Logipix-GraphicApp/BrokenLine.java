import java.util.*;

public class BrokenLine{
	Cell init;
	ArrayList<Position> order;
	BrokenLine(Cell init, ArrayList<Position> order){
		this.init=init;
		this.order=order;
	}
}